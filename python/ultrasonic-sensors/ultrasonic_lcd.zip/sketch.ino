
#include <LiquidCrystal.h> 


LiquidCrystal lcd(7, 8, 9, 10, 11, 12);
const int trigPin = 3;
const int echoPin = 4;

long  duration;
int distance;

void setup() {
  // put your setup code here, to run once:
  // Setup PINs for ultraSonic
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);


  lcd.begin(16, 2);
  lcd.print("UltraSonic Sensor");
  delay(2000);
  

//SETUP Timer01 Interupt for overflow
  TCCR1A = 0;
  TCCR1B = 0b00000101;
  TIMSK1 = 0b00000001;
  interrupts(); 
}

//Perfor function when TIMER01 overflow reached 
ISR (TIMER1_OVF_vect)
{

}

void loop() {

  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);

  digitalWrite (trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  duration=pulseIn(echoPin,HIGH);
  distance=(duration*0.034/2)/2.54;

 //Serial.print("DHT11, \t")
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Time (ms): ");
  lcd.setCursor(0, 1);
  lcd.print("Dist (cm): ");

  //Serial.print("OK,\t"); 
  // set the cursor to (9,0):
  lcd.setCursor(12, 0);
  lcd.print( duration/1000 );

  // set the cursor to (9,1):
  lcd.setCursor(12, 1);
  lcd.print( distance );
   delay(1000); 
}